/bin/netstat {
}
